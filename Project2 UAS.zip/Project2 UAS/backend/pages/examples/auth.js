function login() {
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    if (email === "admin@gmail.com" && password === "123456") {
        alert("Selamat Anda berhasil login");
        window.location = "../../index.html"
        return false;
    } else if (email == "" || password == "") {
        alert ("email & password tidak boleh kosong")
        return false;
    }
    else {
        alert("email atau password yang anda masukkan salah")
    }
}